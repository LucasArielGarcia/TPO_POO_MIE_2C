package FrontEnd.Modelo;

public class ErrorMensage extends Exception {

    public ErrorMensage(String mensaje) {
        super(mensaje);
    }

}
